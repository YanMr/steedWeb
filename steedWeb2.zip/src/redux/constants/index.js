export const SET_USERINFO = 'SET_USERINFO';
export const SET_TAGS = 'SET_TAGS';
export const SET_COLLAPSE = 'SET_COLLAPSE';
