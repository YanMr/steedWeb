import React, { Component } from 'react';
import '../index.scss'


class LogQuery extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  render() {
    return (
      <div className="account">
        <div className="account-header">日志查询</div>
      </div>
    );
  }
}

export default LogQuery;
