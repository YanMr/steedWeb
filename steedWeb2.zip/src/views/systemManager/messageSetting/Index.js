import React, { Component } from 'react';
import '../index.scss'


class MessageSetting extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  render() {
    return (
      <div className="account">
        <div className="account-header">消息设置</div>
      </div>
    );
  }
}

export default MessageSetting;
