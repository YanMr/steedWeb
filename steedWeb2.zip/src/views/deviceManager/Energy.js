import React from 'react';

const Energy = () => <div className="shadow-radius">能耗统计</div>;

export default Energy;
