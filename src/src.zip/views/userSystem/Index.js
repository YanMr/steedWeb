import React from 'react';

const UserSystem = () => <div className="shadow-radius">个人中心</div>;

export default UserSystem;
